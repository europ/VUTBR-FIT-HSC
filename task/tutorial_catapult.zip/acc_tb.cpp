#include "accumulate.h"
#include "mc_scverify.h"

CCS_MAIN(int argv, char *argc){
int a;
int b;
int c; 
int d;
int dout;

  for(int i=0;i<10;i++){
    a = i;
    b = i + 1;
    c = i + 2;
    d = i + 3;

#ifdef CCS_SCVERIFY
//    a_wait_ctrl.cycles = 3;
#endif    
    CCS_DESIGN(accumulate)(a,b,c,d,dout);

    printf("a = %d  b = %d  c = %d  d = %d  dout = %d\n",a,b,c,d,dout);
  }

  CCS_RETURN(0);
}