#pragma design top
void accumulate(int a, int b,  
       int c, int d, int &dout){
  int t1,t2;
  t1 = a + b;
  t2 = t1 + c;
  dout = t2 + d;
}
