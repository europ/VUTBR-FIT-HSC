#ifndef __ACC__
#define __ACC__
#include <stdio.h>
void accumulate(int a, int b,  
       int c, int d, int &dout);

#endif