#define N_TAPS 32

void fir_filter(int din, int coeffs[N_TAPS], int &dout) {
    int acc = 0;
    static int taps[N_TAPS] = {0,};
    
    SHIFT:for (int i=(N_TAPS-1); i>=0; i--) {
        taps[i] = (i==0) ? din : taps[i-1] ;
    }

    MAC:for (int i=(N_TAPS-1); i>=0; i--) {
        acc += taps[i] * coeffs[i] ;
    }

    dout = acc;
}
