#ifndef __MAC__
#define __MAC__
#include <ac_int.h>
#include <ac_fixed.h>
typedef ac_int<8,false> inType;
typedef ac_int<16,false> outType;
//typedef ac_fixed<16,16,false,AC_TRN,AC_SAT> outType;
#endif
