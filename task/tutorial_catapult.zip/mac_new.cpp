#include <ac_int.h>
#include "mac.h"

void mult_acc_new(inType a[4], inType b[4], outType &dout){
  outType acc=0;
  MAC:for(int i=0;i<4;i++){
    acc += a[i]*b[i];
  }
  dout = acc;
}	
