//#ifndef CCS_SCVERIFY
#include <ac_int.h>
#include "mac.h"
void mult_acc(int a[4], int b[4], int &dout);
void mult_acc_new(inType a[4], inType b[4], outType &dout);
#include <iostream>
using namespace std;
int main(int argv, char *argc){ 
   int a[4] = {1,2,3,4};
   int b[4] = {1,1,1,1}; 
   inType a_new[4] = {1,2,3,4};
   inType b_new[4] = {1,1,1,1}; 
   int dout; 
   outType dout_new ;
    
   for(int i=0;i<10;i++){ 
      mult_acc(a,b,dout); 
      mult_acc_new(a_new, b_new,dout_new); 
      if (dout != dout_new) { // compare values
         cout << "ERROR:..." << dout << " != " << dout_new << ", iteration " << i << endl; 
         return 1; 
      } else 
         cout << "Result = " << dout << endl;
      for(int j=0;j<4;j++){ // change input data
         a[j] += 25;
         b[j] += 25;
         a_new[j] += 25;
         b_new[j] += 25;
      }
   }
   return 0;
}
//#endif